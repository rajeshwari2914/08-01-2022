<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Register;
class RegiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexpage(Request $request)
    {
        $login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
            return view('backend.index');
        }
    }
    public function index(Request $request)
    {
        $login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
		$regi=Register::get();
        return view('backend.register_view',compact('regi'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
        $regi=Register::get();
        return view('backend.register',compact('regi'));
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
		'user_name'=>'required',
		'mobile_number'=>'required',
		'password'=>'required',
		]);
		$reg=new Register([
		'name'=>$request->get('user_name'),
		'mobile'=>$request->get('mobile_number'),
		'password'=>$request->get('password'),
        'status'=>'active'
		]);
		$reg->save();
		return redirect('/user/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $regi=Register::find($id);
		return view('backend.register_show',compact('regi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $regi=Register::find($id);
		return view('backend.register_edit',compact('regi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $request->validate([
		'user_name'=>'required',
		'mobile_number'=>'required',
		'password'=>'required',
		]);
		$reg=Register::find($id);
		$reg->name=$request->get('user_name');
		$reg->mobile=$request->get('mobile_number');
		$reg->password=$request->get('password');
		$reg->status='active';
		$reg->update();
		return redirect('/user/create');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $reg=Register::find($id);
		$reg->delete();
		return redirect('/user');
    }
	public function logincode(Request $request)
	{
		$arr = array();
		$mbl=$request->get('mbl');
		$pws=$request->get('pws');
		$usr = Register::where('mobile',''.$mbl)->where('password',''.$pws)->where('status','active')->get();
		if(sizeof($usr)>0)
		{
			$data['status'] = "success";
			$data['msg'] = "Login Success";
			//echo "insert";
			array_push($arr,$data);
		}
		else
		{
			$data['status'] = "Failed";
			$data['msg'] = "Login Fail";
			//echo "insert";
			array_push($arr,$data);
		}
		echo json_encode($arr);
	}
    public function loginchk(Request $request)
    {
        $uname=$request->get('uname');
        $psw=$request->get('psw');
        if($uname=='admin' && $psw="admin123")
        {
            $request->session()->put('uname',$uname);
            return redirect('/index');
        }   
        else
        {
            echo "<script>alert('Enter Valid Inputs')</script>";
            echo "<script>window.location.href='/';</script>";
        }
    }
    public function logout(Request $request)
    {
        //echo $request->session()->get('uname');
        $request->session()->flush();
        return redirect('/');
    }
    public function userstatusupdate($id)
    {
        $user=Register::find($id);
        $user=$user->status;
        if($user=='active')
        {
            $user=Register::find($id);
            $user->status='inactive';
            $user->update();
            return redirect('/user/create');
        }
        else if($user=='inactive')
        {
            $user=Register::find($id);
            $user->status='active';
            $user->update();
            return redirect('/user/create');
        }
    }
}
