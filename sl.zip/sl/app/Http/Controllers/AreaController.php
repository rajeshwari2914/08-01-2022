<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\area_master;
use App\Models\readyreknal;
use App\Models\bharank;
use App\Models\ghasara;
use App\Models\additional_detail;
use DB;
class AreaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	/* Start Jilla Code Here */
	public function jillaform(Request $request)
	{
		$login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
		$jilla=DB::table('area_masters')
				->where('parent_id','=','0')
				->where('super_id','=','0')
				->get();
		return view('backend.jilla',compact('jilla'));
		}
	}
	public function jillastore(Request $request)
	{
		$jilla_name=$request->get('जिल्हा_नाव');
		$status=$request->get('status');
		if($status=='active'||$status=='inactive')
		{
			$data=new area_master([
				'area_name'=>$jilla_name,
				'super_id'=>'0',
				'parent_id'=>'0',
				'status'=>'active'
			]);
			$data->save();
			return redirect('/jilla/create');
		}
		else
		{
			echo "<script>alert('Status Enter Only Active Or Inactive')</script>";
			echo "<script>window.location.href='/jilla/create';</script>";
			
		}
	}
	/*public function jilla()
	{
		$jilla=DB::table('area_masters')
				->where('parent_id','=','0')
				->where('super_id','=','0')
				->get();
		return view('backend.jilla_view',compact('jilla'));
	}*/
	public function jillaedit($id)
	{
		$jilla=area_master::find($id);
		return view('backend.jilla_edit',compact('jilla'));
	}
	public function jillaupdate(Request $request,$id)
	{
		$jilla=area_master::find($id);
		$jilla_name=$request->get('जिल्हा_नाव');
		$jilla->area_name=$jilla_name;
		$jilla->super_id='0';
		$jilla->parent_id='0';
		$jilla->update();
		return redirect('/jilla/create');

	}
	/* End Jilla Code Here */

	/* Start Taluka Code Here */

	public function create(Request $request)
    {
		$login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
		$jilla=DB::table('area_masters')
				->where('parent_id','=','0')
				->get();
		$p=DB::table('area_masters')
				->where('parent_id','!=','0')
				->where('super_id','=','0')
				->get()->toArray();
		//$area_data = array();
		
		/*foreach($p as $pr)
		{
			$data[0]=$pr;
			$sub = DB::table('area_masters')
					->where('parent_id','=',$pr->id)
					->where('super_id','=','0')
					->get();
			$data[1]=$sub;
			array_push($area_data,$data);
		}
		/*$users = DB::table('area_masters as A')
           ->join('area_masters as B', 'A.id', '=', 'B.parent_id')
           ->select('A.parent_id AS menu_name_parent', 'B.parent_id AS menu_name_child')
           ->toSql();*/
		   $users = DB::table('area_masters as A')
           ->join('area_masters as B', 'A.id', '=', 'B.parent_id')
           ->select('A.area_name AS jilla', 'B.area_name AS taluka','B.id as tid','B.status as tstatus')
		   ->where('B.super_id','=','0')
           ->get();
		return view('backend.area_master',compact('jilla','users'));
		}
    }
    public function store(Request $request)
    {
       $data=new area_master([
			'parent_id'=>$request->get('जिल्हा_नाव'),
			'super_id'=>'0',
			'area_name'=>$request->get('तालुका_नाव'),
			'status'=>'active'
		]);
		$data->save();
		return redirect('/taluka/create');
    }
	public function index(Request $request)
    {
		$login=$request->session()->get('uname');
		
		
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
			$p=DB::table('area_masters')
				->where('parent_id','!=','0')
				->where('super_id','=','0')
				->get()->toArray();
				$p=DB::select("SELECT * FROM `area_masters` AS a1 JOIN area_masters as a2 ON a1.parent_id = a2.id WHERE a1.parent_id != '0'");
       		 return view('backend.area_view',compact('p'));
		}
    }
	

	/* End Taluka Code Here */

	/* Start Gram Code Here */

	public function gramform(Request $request)
	{
		$login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
		$jilla=DB::table('area_masters')
					->where('parent_id','=','0')
					->where('super_id','=','0')
					->get();
		$taluka=DB::table('area_masters')
					->where('parent_id','!=','0')
					->get();
		$sub = DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','!=','0')
					->get();
		$users = DB::table('area_masters as A')
					->join('area_masters as B', 'A.id', '=', 'B.parent_id')
					->join('area_masters as C','A.id','=','C.super_id')
					->select('A.area_name AS jilla', 'B.area_name AS taluka','C.area_name as gram','C.id as gid','C.status as gstatus')
					->where('C.super_id','!=','0')
					->get();
		return view('backend.gram',compact('jilla','taluka','sub','users'));
		}
	}
	public function jillaid($id)
	{
		$jillaid=DB::table('area_masters')
					->where('parent_id','=',$id)
					->get();
		return view('backend.display_taluka_id',compact('jillaid'));			
	}
	public function gramstore(Request $request)
	{
		$gram=new area_master([
		'super_id'=>$request->get('जिल्हा_नाव'),
		'parent_id'=>$request->get('तालुका_नाव'),
		'area_name'=>$request->get('ग्रामपंचायत_नाव'),
		'status'=>'active'
		]);
		$gram->save();
		return redirect('/gram/create');
	}
	public function gram()
	{
		/*$p=DB::table('area_masters')
				->where('parent_id','=','0')
				->get()->toArray();*/
//		$area_data = array();
		
	//	foreach($p as $pr)
		//{
			//$data[0]=$pr;
			$sub = DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','!=','0')
					->get();
			//var_dump($sub);
			//$data[1]=$sub;
			//array_push($area_data,$data);
		//}
		//var_dump($area_data);
		return view('backend.gram_view',compact('sub'));
	}
	public function gram_edit($id)
	{
		$area=DB::table('area_masters')
					->where('id','=',$id)
					->get();
		$area_data = array();
		foreach($area as $pr)
		{
			$data[0]=$pr;
			$sub = DB::table('area_masters')
					->where('parent_id','=',$pr->parent_id)
					
					->get();
			//var_dump($sub);
			$data[1]=$sub;
			array_push($area_data,$data);
		}
		$jilla=DB::table('area_masters')
				->where('parent_id','=','0')
				->where('super_id','=','0')
				->get();
		$taluka=DB::table('area_masters')
				->where('parent_id','!=','0')
				->where('super_id','=','0')
				->get();
		$gram1=area_master::find($id);
		return view('backend.gram_edit',compact('area_data','jilla','gram1','taluka'));
	}
	/* End Gram Code Here */






	
	

    
	
	
	public function gram_show(Request $request,$id)
	{
		$area=DB::table('area_masters')
					->where('id','=',$id)
					->get();
		
		$area_data = array();
		
		foreach($area as $pr)
		{
			$data[0]=$pr;
			$sub = DB::table('area_masters')
					->where('parent_id','=',$pr->parent_id)
					->get();
			//var_dump($sub);
			$data[1]=$sub;
			array_push($area_data,$data);
		}
		$gram=DB::table('area_masters')
				->where('parent_id','=','0')
				->get();
		$gram1=area_master::find($id);
		return view('backend.gram_show',compact('area_data','gram','gram1'));
	}
	public function gramupdate(Request $request,$id)
	{
		$gram=area_master::find($id);
		$gram->area_name=$request->get('ग्रामपंचायत_नाव');
		$gram->parent_id=$request->get('तालुका_नाव');
		$gram->super_id=$request->get('जिल्हा_नाव');
		$gram->status='active';
		$gram->update();
		return redirect('/gram/create');
		
	}
	public function gram_remove(Request $request,$id)
	{
		$gram=area_master::find($id);
		$gram->delete();
		return redirect('/gram');
	}
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $p=DB::table('area_masters')
				->where('id','=',$id)
				->get()->toArray();
		$area_data = array();
		
		foreach($p as $pr)
		{
			$data[0]=$pr;
			$sub = DB::table('area_masters')
					->where('parent_id','=',$pr->id)
					->get();
			$data[1]=$sub;
			array_push($area_data,$data);
		}
		return view('backend.area_show',compact('area_data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
	{
		$jilla=DB::table('area_masters')
				->where('parent_id','=','0')
				->get();
		$p=DB::table('area_masters')
				->where('id','=',$id)
				->get()->toArray();
		$area_data = array();
		foreach($p as $pr)
		{
			$data[0]=$pr;
			$sub = DB::table('area_masters')
					->where('parent_id','=',$pr->id)
					->get();
			$data[1]=$sub;
			array_push($area_data,$data);
		}
        $area_edit=area_master::find($id);
		return view('backend.area_edit',compact('area_edit','jilla','area_data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
		'taluka_name'=>'required'
		]);
		$area_update=area_master::find($id);
		$area_update->parent_id=$request->get('जिल्हा_नाव');
		$area_update->super_id='0';
		$area_update->area_name=$request->get('taluka_name');
		$area_update->update();
		return redirect('/taluka/create');
	}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $area_remove=DB::table('area_masters')
						->where('parent_id','=',$id)
						->count();
		if($area_remove==0)
		{
			$area_remove=area_master::find($id);
			$area_remove->delete();
			return redirect('/taluka');
		}
		else
		{
			echo "<script>alert('First Remove its Child Record')</script>";
			echo "<script>window.location.href='/taluka'</script>";
		}
    }
	public function details(Request $request)
	{
		$login=$request->session()->get('uname');
        if($login==null)
        {
            return redirect('/');
        }
        else
        {
		$jilla=DB::table('area_masters')
					->where('parent_id','=','0')
					->where('super_id','=','0')
					->where('status','=','active')
					->get();
		$taluka=DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','=','0')
					->where('status','=','active')
					->get();
		$gram=DB::table('area_masters')
					->where('parent_id','!=','0')
					->where('super_id','!=','0')
					->where('status','=','active')
					->get();
		$varnan=DB::table('varnans')
					->where('status','=','active')
					->limit('5')
					->get();
		return view('backend.details',compact('jilla','taluka','gram','varnan'));
		}
	}
	public function detailsstore(Request $request)
	{
		$jilla=$request->get('jilla_name');
		$taluka=$request->get('taluka_name');
		$gram=$request->get('gram');
		$bharanks=DB::table('bharanks')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->count();
		$readyreknals=DB::table('readyreknals')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->count();
		$ghasaras=DB::table('ghasaras')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->count();
		$additional=DB::table('additional_details')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->count();
		$ghasaras_id=DB::table('ghasaras')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->get();
		$gha=DB::table('varnans')
					->where('status','=','active')
					->count();		
		if($bharanks==1 && $readyreknals==1 && $ghasaras==$gha && $additional==1)
		{
			$demo=array();
			
				for($j=1; $j<=$gha; $j++)
				{
					$data=array(
					"types"=>$request->get('type'.$j),
					"rates"=>$request->get('chf'.$j)
				);
				array_push($demo,$data);
				}
		
			$readyreknal=json_encode($demo);
			$demo1=array();
			for($i=1; $i<=1; $i++)
			{
				for($j=$i; $j<=3; $j++)
				{
					$data=array(
					"type"=>$request->get('type'.$j),
					"amt"=>$request->get('n'.$j)
					);
					array_push($demo1,$data);
					
					//$decode=json_decode($d);
					//print_r($decode);
				}
			}
			$bharank=json_encode($demo1);
			$readyreknals_id=DB::table('readyreknals')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->get();
			$ready=$readyreknals_id[0]->id;
			$edit_ready=readyreknal::find($ready);
			$edit_ready->jilla=$jilla;
			$edit_ready->taluka=$taluka;
			$edit_ready->gram=$gram;
			$edit_ready->rate=$readyreknal;
			$edit_ready->update();
			
			$addi=DB::table('additional_details')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->get();
			$add=$addi[0]->id;
			$additionl_update=additional_detail::find($add);
			$additionl_update->jilla=$jilla;
			$additionl_update->taluka=$taluka;
			$additionl_update->gram=$gram;
			$additionl_update->karach_dar=$request->get('karach_dar');
			$additionl_update->divabatti_kar=$request->get('diva_kar');
			$additionl_update->aarogya_kar=$request->get('aarogya_kar');
			$additionl_update->panipatti_kar=$request->get('panipatt_kar');
			$additionl_update->panipatti_special_kar=$request->get('panipatt_sep_kar');
			$additionl_update->update();

			$bharanks_id=DB::table('bharanks')
					->where('jilla','=',$jilla)
					->where('taluka','=',$taluka)
					->where('gram','=',$gram)
					->get();
			$bhk=$bharanks_id[0]->id;
			$edit_bharank=bharank::find($bhk);
			$edit_bharank->jilla=$jilla;
			$edit_bharank->taluka=$taluka;
			$edit_bharank->gram=$gram;
			$edit_bharank->amt=$bharank;
			$edit_bharank->update();
			
			$gha=DB::table('varnans')
					->where('status','=','active')
					->count();
			
			$i=1;
			
				foreach($ghasaras_id as $g)
				{
					
					$ghasar=$g->id;
					$edit_ghasara=ghasara::find($ghasar);
					$edit_ghasara->jilla=$jilla;
					$edit_ghasara->taluka=$taluka;
					$edit_ghasara->gram=$gram;
					$edit_ghasara->types=$request->get('type'.$i);
					$edit_ghasara->one=$request->get('a'.$i);
					$edit_ghasara->two=$request->get('b'.$i);
					$edit_ghasara->three=$request->get('c'.$i);
					$edit_ghasara->four=$request->get('d'.$i);
					$edit_ghasara->five=$request->get('e'.$i);
					$edit_ghasara->six=$request->get('f'.$i);
					$edit_ghasara->seven=$request->get('g'.$i);
					$edit_ghasara->eight=$request->get('h'.$i);
					$edit_ghasara->greater_than_sixty=$request->get('i'.$i);
					$edit_ghasara->update();
					$i++;
				}
				
		}
		
		else
		{
			$demo=array();
			
				for($j=1; $j<=$gha; $j++)
				{
				$data=array(
				"types"=>$request->get('type'.$j),
				"rates"=>$request->get('chf'.$j)
				);
				array_push($demo,$data);
				}
			
			$readyreknal=json_encode($demo);
			$demo1=array();
			for($i=1; $i<=1; $i++)
			{
				for($j=$i; $j<=3; $j++)
				{
					$data=array(
					"type"=>$request->get('type'.$j),
					"amt"=>$request->get('n'.$j)
					);
					array_push($demo1,$data);
					
					//$decode=json_decode($d);
					//print_r($decode);
				}
			}
			$bharank=json_encode($demo1);
			
			$reday=new readyreknal([
				'jilla'=>$jilla,
				'taluka'=>$taluka,
				'gram'=>$gram,
				'rate'=>$readyreknal
			]);
			$reday->save();

			$additional_kar=new additional_detail([
				'jilla'=>$jilla,
				'taluka'=>$taluka,
				'gram'=>$gram,
				'karach_dar'=>$request->get('karach_dar'),
				'divabatti_kar'=>$request->get('diva_kar'),
				'aarogya_kar'=>$request->get('aarogya_kar'),
				'panipatti_kar'=>$request->get('panipatt_kar'),
				'panipatti_special_kar'=>$request->get('panipatt_sep_kar')
			]);
			$additional_kar->save();

			$bharank=new bharank([
				'jilla'=>$jilla,
				'taluka'=>$taluka,
				'gram'=>$gram,
				'amt'=>$bharank
			]);
			$bharank->save();
			$grh=DB::table('varnans')
					->where('status','=','active')
					->limit('5')
					->get();
			$count=count($grh);
			for($i=1; $i<=$count; $i++)
			{
				$ghasara=new ghasara([
					'jilla'=>$jilla,
					'taluka'=>$taluka,
					'gram'=>$gram,
					'types'=>$request->get('type'.$i),
					'one'=>$request->get('a'.$i),
					'two'=>$request->get('b'.$i),
					'three'=>$request->get('c'.$i),
					'four'=>$request->get('d'.$i),
					'five'=>$request->get('e'.$i),
					'six'=>$request->get('f'.$i),
					'seven'=>$request->get('g'.$i),
					'eight'=>$request->get('h'.$i),
					'greater_than_sixty'=>$request->get('i'.$i)
					
				]);
				
				$ghasara->save();
			}

			
		}
		return redirect('/details');

	}
	public function details_disply()
	{
		$bharank=bharank::get();
		return view('backend.details_disply',compact('bharank'));
	}
	public function gramdetails(Request $request)
	{
		$jilla_id=$request->get('jilla_id');
		$taluka_id=$request->get('taluka_id');
		$gram_id=$request->get('gram_id');
		$bharanks=DB::table('bharanks')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		$readyreknals=DB::table('readyreknals')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		$ghasaras=DB::table('ghasaras')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		$additional=DB::table('additional_details')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		$bharanksc=DB::table('bharanks')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->count();
		$readyreknalsc=DB::table('readyreknals')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->count();
		$ghasarasc=DB::table('ghasaras')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->count();
		$additionalc=DB::table('additional_details')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->count();
		// echo "ghasarasc=".$ghasarasc."<br>";
		// echo "bharanksc=".$bharanksc."<br>";
		// echo "readyreknalsc=".$readyreknalsc."<br>";
		// echo "additionalc=".$additionalc."<br>";
		// exit();

		if($ghasarasc==0 && $bharanksc==0 && $readyreknalsc==0 && $additionalc==0)
		{
			return view('backend.display_all_null');
		}else{
		return view('backend.display_all_points',compact('bharanks','readyreknals','ghasaras','additional'));
		}
	}
	public function jillastatusupdate($id)
	{
		$area=area_master::find($id);
		$s=$area->status;
		if($s=='active')
		{
			$area=area_master::find($id);
			$area->status='inactive';
			$area->update();
			return redirect('/jilla/create');
		}
		else if($s=='inactive')
		{
			$area=area_master::find($id);
			$area->status='active';
			$area->update();
			return redirect('/jilla/create');
		}
	}
	public function statuschktaluka($id)
	{
		$area=area_master::find($id);
		$s=$area->status;
		if($s=='active')
		{
			$area=area_master::find($id);
			$area->status='inactive';
			$area->update();
			return redirect('/taluka/create');
		}
		else if($s=='inactive')
		{
			$area=area_master::find($id);
			$area->status='active';
			$area->update();
			return redirect('/taluka/create');
		}
	}
	public function statuschkgram($id)
	{
		$area=area_master::find($id);
		$s=$area->status;
		if($s=='active')
		{
			$area=area_master::find($id);
			$area->status='inactive';
			$area->update();
			return redirect('/gram/create');
		}
		else if($s=='inactive')
		{
			$area=area_master::find($id);
			$area->status='active';
			$area->update();
			return redirect('/gram/create');
		}
	}
	public function displaytesting()
	{
		$users = DB::table('area_masters as A')
           ->join('area_masters as B', 'A.id', '=', 'B.parent_id')
           ->select('A.area_name AS menu_name_parent', 'B.area_name AS menu_name_child')
           ->get();
		foreach($users as $d)
		{
			echo  "Parent Id:".$d->menu_name_parent.'<br><br><br>';
			echo  "Child Id:".$d->menu_name_child;

		}
	}
	public function gramdata(Request $request)
	{
		$jilla_id=$request->get('jilla_id');
		$taluka_id=$request->get('taluka_id');
		$gram_id=$request->get('gram_id');
		// $survey_info=DB::table('survey_infos')
		// 			->where('jilla_id','=',$jilla_id)
		// 			->where('taluka_id','=',$taluka_id)
		// 			->where('gram_id','=',$gram_id)
		// 			->get();
		// $yr=$survey_info[0]->yr_const;
		// $date=date('Y');
		// $conyr=$date-$yr;
		$bharanks=DB::table('bharanks')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		$readyreknals=DB::table('readyreknals')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		$ghasaras=DB::table('ghasaras')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		return view('backend.getalldetails',compact('bharanks','readyreknals','ghasaras'));
	}
	public function getghasara(Request $request)
	{
		//echo "rani";
		 $jilla_id=$request->get('jilla_id');
		$taluka_id=$request->get('taluka_id');
		$gram_id=$request->get('gram_id');
		$conyr=$request->get('yearcin');
		$ghasaras=DB::table('ghasaras')
					->where('jilla','=',$jilla_id)
					->where('taluka','=',$taluka_id)
					->where('gram','=',$gram_id)
					->get();
		//var_dump($ghasaras);
		return view('backend.getghasara',compact('ghasaras','conyr'));

	}

}
