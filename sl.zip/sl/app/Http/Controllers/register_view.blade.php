@include('backend.header')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Area Details</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Table</span></li>
								<li><span>Area</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">Area Details</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>Id</th>
											<th>User Name</th>
											<th>Mobile Number</th>
											<th>Password</th>
											<th>Status</th>
											<th>Edit</th>
											<th>Update</th>
										</tr>
									</thead>
									<tbody>
									@foreach($regi as $a)
									<tr class="gradeX">
											<td>{{$a->id}}</td>
											<td>{{$a->name}}</td>
											<td>{{$a->mobile}}</td>
											<td>{{$a->password}}</td>
											<td>{{$a->status}}</td>
											<td class="actions">
												
												<a href="{{route('user.edit',$a->id)}}" class="on-default edit-row"><button>Edit</button></a></td>
												<td><form action="{{route('user.destroy',$a->id)}}" method="post">
												@csrf
												@method('DELETE')
												<input type="submit" class="on-default remove-row" value="Delete">
												</form>
											</td>
									</tr>
									@endforeach
									</tbody>
								</table>
							</div>
						</section>
						
						
			@include('backend.footer')