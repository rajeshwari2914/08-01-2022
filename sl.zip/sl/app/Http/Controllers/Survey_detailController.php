<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\survey_info;
use App\Models\survey_detail;
use DB;
class Survey_detailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$survey_detail=DB::table('survey_infos')
						->join('survey_details','survey_details.sid','=','survey_infos.id')
						->select('*','survey_infos.id as sid')
						->get();
        return view('backend.survey_detail_view',compact('survey_detail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $survey_info=survey_info::get();
		return view('backend.survey_details',compact('survey_info'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
		'survey_name'=>'required',
		'income_type'=>'required',
		'sq_ft'=>'required',
		'sq_mtr'=>'required',
		'red_rates'=>'required',
		'dep_rates'=>'required',
		'weight_rates'=>'required',
		'total'=>'required'
		]);
		$survey_details=new survey_detail([
		'sid'=>$request->get('survey_name'),
		'type'=>$request->get('income_type'),
		'sq_ft'=>$request->get('sq_ft'),
		'sq_mtr'=>$request->get('sq_mtr'),
		'readyreknal'=>$request->get('red_rates'),
		'depression'=>$request->get('dep_rates'),
		'bharank'=>$request->get('weight_rates'),
		'total'=>$request->get('total')
		]);
		$survey_details->save();
		return redirect('/survey_detail');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $survey_detail=DB::table('survey_infos')
						->join('survey_details','survey_details.sid','=','survey_infos.id')
						->where('survey_details.id','=',$id)
						->select('*','survey_infos.id as sid')
						->get();
		return view('backend.survey_details_show',compact('survey_detail'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $survey_detail=DB::table('survey_infos')
						->join('survey_details','survey_details.sid','=','survey_infos.id')
						->where('survey_details.id','=',$id)
						->select('*','survey_infos.id as sid')
						->get();
		 $survey_info=survey_info::get();
		return view('backend.survey_detail_edit',compact('survey_detail','survey_info'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
		'survey_name'=>'required',
		'income_type'=>'required',
		'sq_ft'=>'required',
		'sq_mtr'=>'required',
		'red_rates'=>'required',
		'dep_rates'=>'required',
		'weight_rates'=>'required',
		'total'=>'required'
		]);
		$survey_details=survey_detail::find($id);
		$survey_details->sid=$request->get('survey_name');
		$survey_details->type=$request->get('income_type');
		$survey_details->sq_ft=$request->get('sq_ft');
		$survey_details->sq_mtr=$request->get('sq_mtr');
		$survey_details->readyreknal=$request->get('red_rates');
		$survey_details->depression=$request->get('dep_rates');
		$survey_details->bharank=$request->get('weight_rates');
		$survey_details->total=$request->get('total');
		$survey_details->update();
		return redirect('/survey_detail');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $survey_del=survey_detail::find($id);
		$survey_del->delete();
		return redirect('/survey_detail');
    }
}
