<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class survey_detail extends Model
{
    use HasFactory;
	protected $fillable=['sid','type','sq_ft','sq_mtr','readyreknal','depression','bharank','total'];
}
