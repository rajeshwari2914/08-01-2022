<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdditionalDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('additional_details', function (Blueprint $table) {
            $table->id();
            $table->string('karach_dar');
            $table->string('jilla');
            $table->string('taluka');
            $table->string('gram');
            $table->string('divabatti_kar');
            $table->string('aarogya_kar');
            $table->string('panipatti_kar');
            $table->string('panipatti_special_kar');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('additional_details');
    }
}
