<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AreaController;
use App\Http\Controllers\Survey_infoController;
use App\Http\Controllers\Survey_detailController;
use App\Http\Controllers\RegiController;
use App\Http\Controllers\VernanController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('backend.login');
});

Route::get('index',[RegiController::class,'indexpage']);
/** Login Routes **/
Route::post('loginchk',[RegiController::class,'loginchk']);
Route::get('logout',[RegiController::class,'logout']);
/** Jilla Routes **/
Route::get('jilla/create',[AreaController::class,'jillaform']);
Route::post('jillastore',[AreaController::class,'jillastore']);
Route::get('jilla',[AreaController::class,'jilla']);
Route::get('jillaedit/{id}',[AreaController::class,'jillaedit']);
Route::post('jillaupdate/{id}',[AreaController::class,'jillaupdate']);


/** Taluka Routes **/
Route::resource('taluka',AreaController::class);

/** Gram Routes **/
Route::get('gram/create',[AreaController::class,'gramform']);
Route::post('gramstore',[AreaController::class,'gramstore']);
Route::get('gram',[AreaController::class,'gram']);
Route::get('gramedit/{id}',[AreaController::class,'gram_edit']);
Route::post('gramupdate/{id}',[AreaController::class,'gramupdate']);

/*Route::get('gram',[AreaController::class,'gram']);
Route::get('gramedit/{id}',[AreaController::class,'gram_edit']);
Route::post('gramupdate/{id}',[AreaController::class,'gramupdate']);
Route::post('gramremove/{id}',[AreaController::class,'gram_remove']);
Route::post('gram_show/{id}',[AreaController::class,'gram_show']);*/




//Route::post('gramremove/{id}',[AreaController::class,'gram_remove']);
//Route::post('gram_show/{id}',[AreaController::class,'gram_show']);

Route::resource('survey_info',Survey_infoController::class);
Route::get('getgram/{name}',[Survey_infoController::class,'getgram']);

Route::resource('survey_detail',Survey_detailController::class);
Route::resource('user',RegiController::class);
Route::resource('varnan',VernanController::class);
Route::get('details',[AreaController::class,'details']);
Route::post('detailsstore',[AreaController::class,'detailsstore']);
Route::get('details_disply',[AreaController::class,'details_disply']);



Route::get('statuschk/{id}',[AreaController::class,'jillastatusupdate']);
Route::get('statuschktaluka/{id}',[AreaController::class,'statuschktaluka']);
Route::get('statuschkgram/{id}',[AreaController::class,'statuschkgram']);
Route::get('statusinfo/{id}',[Survey_infoController::class,'statusinfo']);
Route::get('statuschkvarnan/{id}',[VernanController::class,'statuschkvarnan']);
Route::get('userstatusupdate/{id}',[RegiController::class,'userstatusupdate']);

Route::get('displaytesting',[AreaController::class,'displaytesting']);

Route::get('printdetails/{id}',[Survey_infoController::class,'printdetails']);