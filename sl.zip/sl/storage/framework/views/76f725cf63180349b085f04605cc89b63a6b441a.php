
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2> सर्वेक्षण फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<form id="form" action="<?php echo e(route('survey_info.store')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title"> सर्वेक्षण फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="jilla_id" class="form-control" id="jilla_id">
												<option value="">जिल्हा नाव</option>
												<?php $__currentLoopData = $jilla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($ai->id); ?>"><?php echo e($ai->area_name); ?></option>
												
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
													
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका <span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="taluka_name" class="form-control" id="taluka" required>
												<option value="">तालुका</option>
												</select>
												<?php $__errorArgs = ['taluka_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">ग्रामपंचायत <span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="gram_name" class="form-control" id="gram_id">
												<option value="">ग्रामपंचायत</option>
												</select>
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन देणार <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_name" class="form-control" required>
												<?php $__errorArgs = ['self_declaration_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">स्वयंघोषणापत्र  करुन घेणार<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="self_declaration_gram_name" class="form-control" required>
												<?php $__errorArgs = ['self_declaration_gram_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">भोगवटदाराचे नांव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="bhogwatdar_name" class="form-control" required>
												<?php $__errorArgs = ['bhogwatdar_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सिटीसव्‍ह मिळकत धारकाचे नांव <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="survey_name" class="form-control" required>
												<?php $__errorArgs = ['survey_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">मोबाइल नं <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="mobile_number" class="form-control" required>
												<?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">आधार नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="adhar_number" class="form-control" required>
												<?php $__errorArgs = ['adhar_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे मोबाइल नं <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="wife_mobile_number" class="form-control" required>
												<?php $__errorArgs = ['wife_mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पत्नीचे आधार नं<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="wife_adhar_number" class="form-control" required>
												<?php $__errorArgs = ['wife_adhar_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Image Upload<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="file" name="img" class="form-control">
												<?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Map Upload<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="file" name="mapimg" class="form-control">
												<?php $__errorArgs = ['mapimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">जुना मिळकत क्र <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="old_tax_number" class="form-control" required>
												<?php $__errorArgs = ['old_tax_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि.सि नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="s_s_number" class="form-control" required>
												<?php $__errorArgs = ['s_s_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">सि. सि. चैा मि.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="s_s_s_m" class="form-control" required>
												<?php $__errorArgs = ['s_s_s_m'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">गट नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="group_no" class="form-control" required>
												<?php $__errorArgs = ['group_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">प्लॉट नं.<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="plot_no" class="form-control"required>
												<?php $__errorArgs = ['plot_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">बांधकाम वर्ष<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="yearcon" class="form-control"  id="yearcon" required>
												<?php $__errorArgs = ['yearcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">उत्तर / दक्षिण  <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="north_south" class="form-control" required>
												<?php $__errorArgs = ['north_south'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">पुर्व / पश्चिम <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="east_west" class="form-control" required>
												<?php $__errorArgs = ['east_west'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<table id="t">
  <colgroup>
    <col class="w">
    <col>
    <col>
    <col>
  </colgroup>
  <thead>
    <tr>
											<th>मिळकतीचे वर्णन</th>
											<th>चाै.फुट</th>
											<th>चाै.मि.</th>
											<th>रेडिरेकनरचे दर</th>
											<th>घसार दर</th>
											<th>भारांक</th>
											<th>एकुण कर</th>
										</tr>
  </thead>
  <tbody>
	<?php
	$i=1;
	?>
	<?php $__currentLoopData = $varanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr onclick="myGeeks(this)">
      <td><?php echo $i;?>. <?php echo e($v->name); ?><input type="hidden" name="varnan<?php echo $i;?>" value="<?php echo e($v->name); ?>"></td>
      <td><input type="text" name="chf<?php echo $i;?>" class="chf" id="chf<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="chm<?php echo $i;?>"class="chm1" id="chm<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="ready<?php echo $i;?>"class="ready1" id="ready<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="ghasara<?php echo $i;?>"class="ghasara1" id="ghasara<?php echo $i;?>" style="width:60px;"></input></td>
	  <td><input type="text"  name="bharank<?php echo $i;?>"class="bharank<?php echo $i;?>" id="bharank<?php echo $i;?>" style="width:60px;"></input></td>

	  <td><input type="text"  name="tol<?php echo $i;?>" id="tol<?php echo $i;?>" style="width:60px;"></input></td>
	  
    </tr>
	
	<?php
	$i++;
	?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<input type="hidden" value="<?php echo $i;?>" id="rowcount">
    </tr>
	
  </tbody>
</table>
										<div class="form-group">
											<label class="col-sm-3 control-label">नळ कनेक्शन <span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="nalcon" class="form-control" required>
													<option value="Regular">Regular</option>
													<option value="Special">Special</option>
												</select>
												<?php $__errorArgs = ['nalcon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label"> शाैचालय <span class="required">*</span></label>
											<div class="col-sm-9">
											<select name="washroom" class="form-control" required>
													<option value="Yes">Yes</option>
													<option value="No">No</option>
												</select>
												<?php $__errorArgs = ['washroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label"> उत्तर <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="north" class="form-control" required>
												<?php $__errorArgs = ['north'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label">दक्षिण <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="south" class="form-control" required>
												<?php $__errorArgs = ['south'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label">पूर्व <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="east" class="form-control" required>
												<?php $__errorArgs = ['east'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
										<label class="col-sm-1 control-label">चर्तु:सिमा</label>
											<label class="col-sm-2 control-label">पश्चिम <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="west" class="form-control" required>
												<?php $__errorArgs = ['west'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">व्दार <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" name="gate" class="form-control" required>
												<?php $__errorArgs = ['gate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
											
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
				<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
		<script>
		$(document).ready(function(){
		$("#gram_id").on("change",function()
   		 	{
        		var id=$(this).val();
				//alert(id);
				var data={
				jilla_id:$("#jilla_id").val(),
				taluka_id:$("#taluka").val(),
				gram_id:$(this).val()
			}
			//console.log(data);
			$.ajax({
			url:'/api/gramdata/',
			method:'get',
			data:data,
			success:function(data)
			{
				var test=data.split("::");
				var $row=$("#rowcount").val();
				$i=1;
				for($j=6; $j<=8; $j++)
				{
					$("#bharank"+$j).val(test[0+$i-1]);
					$i++;
				}
				for($i=1; $i<$row-2; $i++)
				{
					$("#ready"+$i).val(test[2+$i]);
					//alert($i);
				}
				
			},
			error:function(data)
			{
				alert(data);
			}
		});
		});
		$("#yearcon").on("change",function(){
			var id=$(this).val();
			var date=new Date().getFullYear();
			var remd=date-id;
			var data={
				jilla_id:$("#jilla_id").val(),
				taluka_id:$("#taluka").val(),
				gram_id:$("#gram_id").val(),
				yearcin:remd
			}
			$.ajax({
				url:'/api/getghasara/',
				method:'get',
				data:data,
				success:function(data)
				{
					var test=data.split("::");
					$("#ghasara1").val(test[0])
					for($k=2; $k<=5; $k++)
					{
						$("#ghasara"+$k).val(test[0+$k-1]);
					}
				},
				error:function(data)
				{
					//alert(data);
				}

			});
		});
		});
		</script>
		<script>
       	//  function myGeeks(x) {
        //     //alert("Row index is: " + x.rowIndex);
		// 	var chm="chm"+ x.rowIndex;
		// 	var chf="chf"+ x.rowIndex;
			
		// 	//alert(id);
		// 	var chm=document.getElementById(chm).value;
		// 	var chf=document.getElementById(chf).value;
		// 	alert("chf="+chf);
		// 	var mtr=chf*chf/10.764;
		// 	alert(mtr);
		// 	document.getElementById('chf1').innerHTML ="hi";
        // }
    	</script>
		
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gayatriinfotech/sl/resources/views/backend/survey_info.blade.php ENDPATH**/ ?>