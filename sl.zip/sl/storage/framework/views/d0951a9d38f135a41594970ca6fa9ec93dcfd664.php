<?php

$arr3=array();
$numberword="";
foreach($ghasaras as $k)
{
    if($conyr==1)
    {
        $data=array(
            "one"=>$k->one
        );
        array_push($arr3,$data);
        $numberword='one';
    }
    else if($conyr==2)
    {
        $data=array(
        "two"=>$k->two
        );
        array_push($arr3,$data);
        $numberword='two';
    }
    else if($conyr==3)
    {
        $data=array(
        "three"=>$k->three
        );
        array_push($arr3,$data);
        $numberword='three';
    }
    else if($conyr==4)
    {
        $data=array(
            "four"=>$k->four
        );
        array_push($arr3,$data);
        $numberword='four';
    }
    else if($conyr==5)
    {
        $data=array(
            "five"=>$k->five
        );
        array_push($arr3,$data);
        $numberword='five';
    }
    else if($conyr==6)
    {
        $data=array(
            "six"=>$k->six
        );
        array_push($arr3,$data);
        $numberword='six';
    }
    else if($conyr==7)
    {
        $data=array(
            "seven"=>$k->seven
        );
        array_push($arr3,$data);
        $numberword='seven';
    }
    else if($conyr==8)
    {
        $data=array(
            "eight"=>$k->eight
        );
        array_push($arr3,$data);
        $numberword='eight';
    }
    else if($conyr>8)
    {
        $data=array(
        "greater_than_sixty"=>$k->greater_than_sixty
        );
        array_push($arr3,$data);
        $numberword='greater_than_sixty';
    }
}
echo $arr3[0][$numberword]."::".$arr3[1][$numberword]."::".$arr3[2][$numberword]."::".$arr3[3][$numberword]."::".$arr3[4][$numberword];
?><?php /**PATH /home/gayatriinfotech/sl/resources/views/backend/getghasara.blade.php ENDPATH**/ ?>