
<?php $__env->startSection('index-content'); ?>
<div class="row">
						
				
				<section role="main" class="content-body">
					<header class="page-header">
						<h2>सर्वेक्षण तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">सर्वेक्षण तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>सर्वेक्षण क्र. </th>
											<th>जिल्हा नाव</th>
											<th>तालुका</th>
											<th>ग्रामपंचायत</th>
											
											<th>स्वयंघोषणापत्र  करुन देणार</th>
											<th class="hidden-phone">स्वयंघोषणापत्र  करुन घेणार</th>
											<th class="hidden-phone">भोगवटदाराचे नांव</th>
											<th class="hidden-phone">सिटीसव्‍ह मिळकत धारकाचे नांव </th>
											<th class="hidden-phone">मोबाइल नं</th>
											<th class="hidden-phone">आधार नं</th>
											
											<th class="hidden-phone">Edit</th>
											<th class="hidden-phone">Delete</th>
											<th class="hidden-phone">Status</th>
											<th class="hidden-phone">View Details</th>
											<th class="hidden-phone">Print Details</th>
											
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $survey_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr class="gradeX">
											<td><?php echo e($sur->id); ?></td>
											<td><?php echo e($sur->jilla_id); ?></td>
											<td><?php echo e($sur->area_name); ?></td>
											
											<td><?php echo e($sur->gram_id); ?></td>
											
											<td class="center hidden-phone"><?php echo e($sur->name); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->gram_name); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->name2); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->survey_name); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->mbl); ?></td>
											<td class="center hidden-phone"><?php echo e($sur->adhar); ?></td>
											
											
											<td class="actions"><button class="btn btn-primary"><a href="<?php echo e(route('survey_info.edit',$sur->id)); ?>" class="on-default edit-row" style="text-decoration:none;color:white;">Edit</a></button></td>
											<td class="actions">
												<form method="post" action="<?php echo e(route('survey_info.destroy',$sur->id)); ?>">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<input type="submit" name="delete" value="Delete" class="btn btn-danger">
												</form>
											</td>
											<?php 
											$s=$sur->status;
											if($s=='active')
											{
											?>
											<td><a href="/statusinfo/<?php echo e($sur->id); ?>" class="btn btn-success" id="statuschk" value="<?php echo e($sur->id); ?>"><?php echo e($sur->status); ?></a></td>
											<?php
											}else{
											?>
											<td><a href="/statusinfo/<?php echo e($sur->id); ?>" class="btn btn-warning" id="statuschk" value="<?php echo e($sur->id); ?>"><?php echo e($sur->status); ?></a></td>
											<?php
											}
											?>
											<td class="actions"><button class="btn btn-success"><a href="<?php echo e(route('survey_info.show',$sur->id)); ?>" class="on-default edit-row" style="text-decoration:none;color:white;">View Details</a></button></td>
											<td><a href="/printdetails/<?php echo e($sur->id); ?>">Print Details</a></td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</section>
						</section>
						
</div>	
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\survey\resources\views/backend/survey_view.blade.php ENDPATH**/ ?>