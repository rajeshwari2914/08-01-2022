
<?php $__env->startSection('index-content'); ?>
				<section role="main" class="content-body">
					<header class="page-header">
						<h2>तालुका तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>तालुका</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">मिळकतीचे वर्णन तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" >
									<thead>
										<tr>
											<th>मिळकतीचे वर्णन क्र. </th>
											<th>मिळकतीचे वर्णन नाव</th>
											
											<th>Status</th>
											
										</tr>
									</thead>
									<tbody>
									<tr class="gradeX">
											<td><?php echo e($varnan->id); ?></td>
											<td><?php echo e($varnan->name); ?></td>
											
											<td><?php echo e($varnan->status); ?></td>
											
									</tr>
									
									</tbody>
								</table>
							</div>
						</section>
						
						
						
						
					<!-- end: page -->
				</section>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\survey\resources\views/backend/varnan_show.blade.php ENDPATH**/ ?>