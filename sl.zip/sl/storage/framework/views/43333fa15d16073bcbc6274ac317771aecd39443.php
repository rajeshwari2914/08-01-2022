
<?php $__env->startSection('index-content'); ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>तालुका फॉर्म </h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span>तालुका</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="<?php echo e(route('taluka.store')); ?>" class="form-horizontal" method="post">
							<?php echo csrf_field(); ?>
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">तालुका फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
										<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="जिल्हा_नाव" class="form-control" required>
												<option value="">जिल्हा नाव</option>
												<?php $__currentLoopData = $jilla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($ai->id); ?>"><?php echo e($ai->area_name); ?></option>
												
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
													
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" 
												name="तालुका_नाव" class="form-control" required>
												<?php $__errorArgs = ['तालुका_नाव'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												<font size="3" color="red"><?php echo e($message); ?></font>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>	
											</div>
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
					<!-- start: page -->
					<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">तालुका तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>तालुका क्र. </th>
											<th>Jilla Name</th>
											<th>तालुका नाव</th>
											
											<th>Status</th>
											<th>Edit</th>
											
										</tr>
									</thead>
									<tbody>
									<?php
									$i=1;
									?>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="gradeX">
											<td><?php echo e($a->tid); ?></td>
											<td><?php echo e($a->jilla); ?></td>
											<td><?php echo e($a->taluka); ?></td>
											<?php 
											$s=$a->tstatus;
											if($s=='active')
											{
											?>
											<td><a href="/statuschktaluka/<?php echo e($a->tid); ?>" class="btn btn-success" id="statuschk" value="<?php echo e($a->tid); ?>"><?php echo e($a->tstatus); ?></a></td>
											<?php
											}else{
											?>
											<td><a href="/statuschktaluka/<?php echo e($a->tid); ?>" class="btn btn-warning" id="statuschk" value="<?php echo e($a->tid); ?>"><?php echo e($a->tstatus); ?></a></td>
											<?php
											}
											?>
											<td class="actions">
												
											<button class="btn btn-primary"><a href="<?php echo e(route('taluka.edit',$a->tid)); ?>" style="text-decoration:none;color:white;" class="on-default edit-row">Edit</a></button></td>
												
											
									</tr>
									<?php
									$i++
									?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									</tbody>
								</table>
							</div>
						</section>
				</section>
				
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gayatriinfotech/sl/resources/views/backend/area_master.blade.php ENDPATH**/ ?>