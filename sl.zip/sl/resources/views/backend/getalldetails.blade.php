<?php
foreach($bharanks as $bh)
{
    $d=$bh->amt;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr1=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr1,$value);
            
        }
    }
}

foreach($readyreknals as $bh)
{
    $d=$bh->rate;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr2=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr2,$value);
            
        }
    }
    
}
// $arr3=array();
// foreach($ghasaras as $k)
// {
//     if($conyr==1)
//     {
//         $data=array(
//             "one"=>$k->one
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==2)
//     {
//         $data=array(
//         "two"=>$k->two
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==3)
//     {
//         $data=array(
//         "three"=>$k->three
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==4)
//     {
//         $data=array(
//             "four"=>$k->four
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==5)
//     {
//         $data=array(
//             "five"=>$k->five
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==6)
//     {
//         $data=array(
//             "six"=>$k->six
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==7)
//     {
//         $data=array(
//             "seven"=>$k->seven
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr==8)
//     {
//         $data=array(
//             "eight"=>$k->eight
//         );
//         array_push($arr3,$data);
//     }
//     else if($conyr>8)
//     {
//         $data=array(
//         "greater_than_sixty"=>$k->greater_than_sixty
//         );
//         array_push($arr3,$data);
//     }
// }
 echo $arr1[1]."::".$arr1[3]."::".$arr1[5]."::".$arr2[1]."::".$arr2[3]."::".$arr2[5]."::".$arr2[7]."::".$arr2[9]."::".$arr2[11];
?>