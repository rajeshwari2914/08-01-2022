
@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>ग्रामपंचायत फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span>ग्रामपंचायत</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
							<form id="form" action="/gramstore" class="form-horizontal" method="post">
							@csrf
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title">ग्रामपंचायत फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
									<div class="form-group">
											<label class="col-sm-3 control-label">जिल्हा नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="जिल्हा_नाव" class="form-control" id="jillaid" required>
												<option value="">जिल्हा नाव</option>
												@foreach($jilla as $ai)
												<option value="{{$ai->id}}">{{$ai->area_name}}</option>
												
												@endforeach
												</select>
													
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">तालुका नाव<span class="required">*</span></label>
											<div class="col-sm-9">
												<select name="तालुका_नाव" class="form-control" id="aname">
												<option value="">तालुका नाव</option>
												</select>
													
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">ग्रामपंचायत नाव <span class="required">*</span></label>
											<div class="col-sm-9">
												<input type="text" 
												name="ग्रामपंचायत_नाव" class="form-control" required>
													
											</div>
											
										</div>
										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
					<!-- start: page -->
					<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">ग्रामपंचायत तपशील </h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th>ग्रामपंचायत क्र.</th>
											<th>जिल्हा नाव</th>
											<th>तालुका नाव</th>
											<th>ग्रामपंचायत नाव</th>
											<th>Status</th>
											<th>Edit</th>
										
										</tr>
									</thead>
									<tbody>
									@foreach($users as $a)
									<tr class="gradeX">
										
												<td>{{$a->gid}}</td>
												<td>{{$a->jilla}}</td>
												<td>{{$a->taluka}}</td>
												<td>{{$a->gram}}</td>
												<?php 
											$s=$a->gstatus;
											if($s=='active')
											{
											?>
											<td><a href="/statuschkgram/{{$a->gid}}" class="btn btn-success" id="statuschk" value="{{$a->gid}}">{{$a->gstatus}}</a></td>
											<?php
											}else{
											?>
											<td><a href="/statuschkgram/{{$a->gid}}" class="btn btn-warning" id="statuschk" value="{{$a->gid}}">{{$a->gstatus}}</a></td>
											<?php
											}
											?>
											<td><button class="btn btn-primary"><a href="/gramedit/{{$a->gid}}" style="text-decoration:none;color:white;">Edit</a></button></td>
									</tr>
									@endforeach
									</tbody>
								</table>
							</div>
						</section>
				</section>
				<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    			<script>
				$(document).ready(function(){
					$("#jillaid").on("change",function(){
						var id=$(this).val();
						$.ajax({
							url:'/api/jillaid/'+id,
							method:'get',
							success:function(data)
							{
								//var test=data.split("::");
								$("#aname").html(data);
								
							},	
							error:function(data)
							{
								$("#aname").html("");
							}
						});
					});
					
				});	
				</script>
	@stop	