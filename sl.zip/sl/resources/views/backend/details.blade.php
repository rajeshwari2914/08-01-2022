<!doctype html>
<html class="fixed">
	<head>

		<!-- Basic -->
		<meta charset="UTF-8">

		<title>Advanced Tables | Okler Themes | Porto-Admin</title>
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">
		
		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="{{asset('backend/assets/vendor/bootstrap/css/bootstrap.css')}}" />
		<link rel="stylesheet" href="{{asset('backend/assets/vendor/font-awesome/css/font-awesome.css')}}" />
		<link rel="stylesheet" href="{{asset('backend/assets/vendor/magnific-popup/magnific-popup.css')}}" />
		<link rel="stylesheet" href="{{asset('backend/assets/vendor/bootstrap-datepicker/css/datepicker3.css')}}" />

		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="{{asset('backend/assets/vendor/select2/select2.css')}}" />
		<link rel="stylesheet" href="{{asset('backend/assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')}}" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="{{asset('backend/assets/stylesheets/theme.css')}}" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="{{asset('backend/assets/stylesheets/skins/default.css')}}" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="{{asset('backend/assets/stylesheets/theme-custom.css')}}">

		<!-- Head Libs -->
		<script src="{{asset('backend/assets/vendor/modernizr/modernizr.js')}}"></script>
		
		<style>


table {
  width: 100%;
  margin: 20px auto;
  table-layout: auto;
}

.fixed {
  table-layout: fixed;
}

table,
td,
th {
  border-collapse: collapse;
}

th,
td {
  padding: 10px;
  border: solid 1px;
  text-align: center;
}

.w {
  width: 400px;
}
</style>
		
	</head>
	<body>
		<section class="body">

			<!-- start: header -->
			<header class="header">
				<div class="logo-container">
					<a href="../" class="logo">
						<img src="{{asset('backend/assets/images/logo.png')}}" height="35" alt="Porto Admin" />
					</a>
					<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
			
				<!-- start: search & user box -->
				<div class="header-right">
			
					<form action="pages-search-results.html" class="search nav-form">
						<div class="input-group input-search">
							<input type="text" class="form-control" name="q" id="q" placeholder="Search...">
							<span class="input-group-btn">
								<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</form>
			
					<span class="separator"></span>
			
					<ul class="notifications">
						<li>
							<a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown">
								<i class="fa fa-tasks"></i>
								<span class="badge">3</span>
							</a>
			
							<div class="dropdown-menu notification-menu large">
								<div class="notification-title">
									<span class="pull-right label label-default">3</span>
									Tasks
								</div>
			
								<div class="content">
									<ul>
										<li>
											<p class="clearfix mb-xs">
												<span class="message pull-left">Generating Sales Report</span>
												<span class="message pull-right text-dark">60%</span>
											</p>
											<div class="progress progress-xs light">
												<div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
											</div>
										</li>
			
										<li>
											<p class="clearfix mb-xs">
												<span class="message pull-left">Importing Contacts</span>
												<span class="message pull-right text-dark">98%</span>
											</p>
											<div class="progress progress-xs light">
												<div class="progress-bar" role="progressbar" aria-valuenow="98" aria-valuemin="0" aria-valuemax="100" style="width: 98%;"></div>
											</div>
										</li>
			
										<li>
											<p class="clearfix mb-xs">
												<span class="message pull-left">Uploading something big</span>
												<span class="message pull-right text-dark">33%</span>
											</p>
											<div class="progress progress-xs light mb-xs">
												<div class="progress-bar" role="progressbar" aria-valuenow="33" aria-valuemin="0" aria-valuemax="100" style="width: 33%;"></div>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</li>
						<li>
							<a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown">
								<i class="fa fa-envelope"></i>
								<span class="badge">4</span>
							</a>
			
							<div class="dropdown-menu notification-menu">
								<div class="notification-title">
									<span class="pull-right label label-default">230</span>
									Messages
								</div>
			
								<div class="content">
									<ul>
										<li>
											<a href="#" class="clearfix">
												<figure class="image">
													<img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Doe Junior" class="img-circle" />
												</figure>
												<span class="title">Joseph Doe</span>
												<span class="message">Lorem ipsum dolor sit.</span>
											</a>
										</li>
										<li>
											<a href="#" class="clearfix">
												<figure class="image">
													<img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Junior" class="img-circle" />
												</figure>
												<span class="title">Joseph Junior</span>
												<span class="message truncate">Truncated message. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sit amet lacinia orci. Proin vestibulum eget risus non luctus. Nunc cursus lacinia lacinia. Nulla molestie malesuada est ac tincidunt. Quisque eget convallis diam, nec venenatis risus. Vestibulum blandit faucibus est et malesuada. Sed interdum cursus dui nec venenatis. Pellentesque non nisi lobortis, rutrum eros ut, convallis nisi. Sed tellus turpis, dignissim sit amet tristique quis, pretium id est. Sed aliquam diam diam, sit amet faucibus tellus ultricies eu. Aliquam lacinia nibh a metus bibendum, eu commodo eros commodo. Sed commodo molestie elit, a molestie lacus porttitor id. Donec facilisis varius sapien, ac fringilla velit porttitor et. Nam tincidunt gravida dui, sed pharetra odio pharetra nec. Duis consectetur venenatis pharetra. Vestibulum egestas nisi quis elementum elementum.</span>
											</a>
										</li>
										<li>
											<a href="#" class="clearfix">
												<figure class="image">
													<img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joe Junior" class="img-circle" />
												</figure>
												<span class="title">Joe Junior</span>
												<span class="message">Lorem ipsum dolor sit.</span>
											</a>
										</li>
										<li>
											<a href="#" class="clearfix">
												<figure class="image">
													<img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Junior" class="img-circle" />
												</figure>
												<span class="title">Joseph Junior</span>
												<span class="message">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sit amet lacinia orci. Proin vestibulum eget risus non luctus. Nunc cursus lacinia lacinia. Nulla molestie malesuada est ac tincidunt. Quisque eget convallis diam.</span>
											</a>
										</li>
									</ul>
			
									<hr />
			
									<div class="text-right">
										<a href="#" class="view-more">View All</a>
									</div>
								</div>
							</div>
						</li>
						<li>
							<a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown">
								<i class="fa fa-bell"></i>
								<span class="badge">3</span>
							</a>
			
							<div class="dropdown-menu notification-menu">
								<div class="notification-title">
									<span class="pull-right label label-default">3</span>
									Alerts
								</div>
			
								<div class="content">
									<ul>
										<li>
											<a href="#" class="clearfix">
												<div class="image">
													<i class="fa fa-thumbs-down bg-danger"></i>
												</div>
												<span class="title">Server is Down!</span>
												<span class="message">Just now</span>
											</a>
										</li>
										<li>
											<a href="#" class="clearfix">
												<div class="image">
													<i class="fa fa-lock bg-warning"></i>
												</div>
												<span class="title">User Locked</span>
												<span class="message">15 minutes ago</span>
											</a>
										</li>
										<li>
											<a href="#" class="clearfix">
												<div class="image">
													<i class="fa fa-signal bg-success"></i>
												</div>
												<span class="title">Connection Restaured</span>
												<span class="message">10/10/2014</span>
											</a>
										</li>
									</ul>
			
									<hr />
			
									<div class="text-right">
										<a href="#" class="view-more">View All</a>
									</div>
								</div>
							</div>
						</li>
					</ul>
			
					<span class="separator"></span>
			
					<div id="userbox" class="userbox">
						<a href="#" data-toggle="dropdown">
							<figure class="profile-picture">
								<img src="{{asset('backend/assets/images/!logged-user.jpg')}}" alt="Joseph Doe" class="img-circle" data-lock-picture="{{asset('backend/assets/images/!logged-user.jpg')}}" />
							</figure>
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name">John Doe Junior</span>
								<span class="role">administrator</span>
							</div>
			
							<i class="fa custom-caret"></i>
						</a>
			
						<div class="dropdown-menu">
							<ul class="list-unstyled">
								<li class="divider"></li>
								<li>
									<a role="menuitem" tabindex="-1" href="pages-user-profile.html"><i class="fa fa-user"></i> My Profile</a>
								</li>
								<li>
									<a role="menuitem" tabindex="-1" href="#" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
								</li>
								<li>
									<a role="menuitem" tabindex="-1" href="pages-signin.html"><i class="fa fa-power-off"></i> Logout</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
				
					<div class="sidebar-header">
						
						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
						</div>
					</div>
				
					<div class="nano">
						<div class="nano-content">
						<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-main">
									<li>
										<a href="/">
											<i class="fa fa-home" aria-hidden="true"></i>
											<span>Dashboard</span>
										</a>
									</li>
									<li class="nav-parent">
										<a href="/jilla/create">
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>जिल्हा </span>
										</a>
										
									</li>
									<li class="nav-parent">
										<a href="/taluka/create">
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>तालुका </span>
										</a>
										<!--<ul class="nav nav-children">
											<li>
												<a href="/taluka/create">
													 Add New
												</a>
											</li>
											<li>
												<a href="/taluka">
													 View All
												</a>
											</li>
											
										</ul>-->
									</li>
									<li class="nav-parent">
										<a href="/gram/create">
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>ग्रामपंचायत</span>
										</a>
										<!--<ul class="nav nav-children">
											<li>
												<a >
													 Add New
												</a>
											</li>
											<li>
												<a href="/gram">
													 View All
												</a>
											</li>
											
										</ul>-->
									</li>
									<li class="nav-parent">
										<a href="/varnan/create">
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>मिळकतीचे वर्णन </span>
										</a>
										<!--<ul class="nav nav-children">
											<li>
												<a href="/varnan/create">
													 Add New
												</a>
											</li>
											<li>
												<a href="/varnan">
													 View All
												</a>
											</li>
											
										</ul>-->
									</li>
									<li class="nav-parent">
										<a>
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>सर्वेक्षण</span>
										</a>
										<ul class="nav nav-children">
											<li>
												<a href="/survey_info/create">
													 Add New
												</a>
											</li>
											<li>
												<a href="/survey_info">
													 View All
												</a>
											</li>
											
										</ul>
									</li>
									<li class="nav-parent">
										<a href="/user/create">
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>वापरकर्ता</span>
										</a>
										<!--<ul class="nav nav-children">
											<li>
												<a href="/user/create">
													 Add New
												</a>
											</li>
											<li>
												<a href="/user">
													 View All
												</a>
											</li>
											
										</ul>-->
									</li>
									<li class="nav-parent">
										<a href="/details">
											<i class="fa fa-list-alt" aria-hidden="true"></i>
											<span>कॅल्क्युलेटर</span>
										</a>
										
									</li>
								</ul>
							</nav>
				
							
							
				
						</div>
				
					</div>
				
				</aside>
				<!-- end: sidebar -->
				<section role="main" class="content-body">
					<header class="page-header">
						<h2> सर्वेक्षण फॉर्म</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>फॉर्म</span></li>
								<li><span> सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
							<form action="/detailsstore" method="post">
							@csrf
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>

										<h2 class="panel-title"> सर्वेक्षण फॉर्म</h2>
										<!--<p class="panel-subtitle">
											Basic validation will display a label with the error after the form control.
										</p>-->
									</header>
									<div class="panel-body">
                                        <div class="form-group">
											<label class="col-sm-1 control-label">जिल्हा <span class="required">*</span></label>
											<div class="col-sm-3">
												<select name="jilla_name" class="form-control" id="jilla_name" required>
												<option value="">जिल्हा</option>
												@foreach($jilla as $ai)
												<option value="{{$ai->id}}">{{$ai->area_name}}</option>
												
												@endforeach
												</select>
												@error('jilla_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
                                            <label class="col-sm-1 control-label">तालुका <span class="required">*</span></label>
											<div class="col-sm-3">
												<select name="taluka_name" class="form-control" id="taluka_name" required>
												<option value="">तालुका</option>
												</select>
												@error('taluka_name')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
                                            <label class="col-sm-1 control-label">ग्राम <span class="required">*</span></label>
											<div class="col-sm-3">
												<select name="gram" class="form-control" id="gramonchange">
												<option value="">ग्राम</option>
												</select>
												@error('gram')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-1 control-label">कराचा दर<span class="required">*</span></label>
											<div class="col-sm-3">
												<input type="text" name="karach_dar" class="form-control" id="karach_dar" required>
												@error('karach_dar')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											<label class="col-sm-1 control-label">दिवाबत्ती कर<span class="required">*</span></label>
											<div class="col-sm-3">
												<input type="text" name="diva_kar" class="form-control" id="diva_kar" required>
												@error('diva_kar')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											<label class="col-sm-1 control-label">आरोग्य कर<span class="required">*</span></label>
											<div class="col-sm-3">
												<input type="text" name="aarogya_kar" class="form-control" id="aarogya_kar" required>
												@error('aarogya_kar')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-1 control-label">पाणीपट्टी दर<span class="required">*</span></label>
											<div class="col-sm-5">
												<input type="text" name="panipatt_kar" class="form-control" id="panipatt_kar" required>
												@error('panipatt_kar')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											<label class="col-sm-1 control-label">पाणीपट्टी स्पेशल कर<span class="required">*</span></label>
											<div class="col-sm-5">
												<input type="text" name="panipatt_sep_kar" class="form-control" id="panipatt_sep_kar" required>
												@error('panipatt_sep_kar')
												<font size="3" color="red">{{$message}}</font>
												@enderror	
											</div>
											
										</div>
										<div class="form-group">
											<label class="col-sm-6 control-label">रेडिरेकनरचे दर <span class="required">*</span></label>
											<label class="col-sm-6 control-label">भारांक <span class="required">*</span></label>
											<div class="col-sm-6">
                                                <table id="t">
                                                <colgroup>
                                                    <col class="w">
                                                    <col>
                                                    <col>
                                                    <col>
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th>मिळकतीचे वर्णन</th>
                                                        <th>रेडिरेकनरचे दर</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $i=1;
                                                    ?>
                                                    @foreach($varnan as $d)
                                                    <tr>
                                                    <td>{{$d->name}}</td>
                                                    <input type="hidden" name="type<?php echo $i;?>" value="{{$d->name}}">
                                                    <td><input type="text" id="chf<?php echo $i;?>" name="chf<?php echo $i;?>" style="width: 60px;height: 40px;"></input></td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                    ?>
                                                    @endforeach
                                                    
                                                </tbody>
                                                
                                                </table>
                                            </div>
											<div class="col-sm-6">
                                                <table id="t">
                                                <colgroup>
                                                    <col class="w">
                                                    <col>
                                                    <col>
                                                    <col>
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th>भारांक प्रकार</th>
                                                        <th>भारांक दर</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <tr>
                                                    <td>निवासी</td>
                                                    <input type="hidden" name="type1" value="निवासी">
                                                    <td><input type="text" name="n1" id="nivas" style="width: 60px;height: 40px;" value="0"></input></td>
                                                    </tr>
                                                    <tr>
                                                    <td>वाणिजक</td>
                                                    <input type="hidden" name="type2" value="वाणिजक">
                                                    <td><input type="text" name="n2" id="commers" style="width: 60px;height: 40px;" value="0"></input></td>
                                                    </tr>
                                                    <tr>
                                                    <td>औधोगिक</td>
                                                    <input type="hidden" name="type3" value="औधोगिक">
                                                    <td><input type="text" name="n3" id="indrstrial" style="width: 60px;height: 40px;" value="0"></input></td>
                                                    </tr>
                                                    
                                                </tbody>
                                                </table>
                                            </div>
                                            
                                        </div>
										
										
									</div>
                                    <div class="panel-body">
                                        <div class="form-group">
											<label class="col-sm-12 control-label">घंसारा <span class="required">*</span></label>
                                            <div class="col-sm-12">
                                                <table id="t">
                                                <colgroup>
                                                    <col class="w">
                                                    <col>
                                                    <col>
                                                    <col>
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th>वय वर्ष</th>
                                                        <td>०-२</td>
                                                        <td>२-५</td>
                                                        <td>५-१०</td>
                                                        <td>१०-२०</td>
                                                        <td>२०-३०</td>
                                                        <td>३०-४०</td>
                                                        <td>४०-५०</td>
                                                        <td>५०-६०</td>
                                                        <td>६० पेक्षा जास्त</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php
													$i=1;
													?>
                                                    @foreach($varnan as $v)
                                                    <tr>
                                                    <th>{{$v->name}}</th>
                                                    <input type="hidden" name="type<?php echo $i;?>" value="{{$v->name}}">
                                                    <td><input type="text" id="a<?php echo $i;?>" name="a<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="b<?php echo $i;?>" name="b<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="c<?php echo $i;?>" name="c<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="d<?php echo $i;?>" name="d<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="e<?php echo $i;?>" name="e<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="f<?php echo $i;?>" name="f<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="g<?php echo $i;?>" name="g<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="h<?php echo $i;?>" name="h<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <td><input type="text" id="i<?php echo $i;?>" name="i<?php echo $i;?>" style="width: 60px;height: 40px;" value="0"></td>
                                                    <?php
													$i++;
													?>
                                                    </tr>
													@endforeach
                                                    </tbody>
                                                </table>
                                            </div>
										</div>
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-primary" type="submit">Submit</button>
												<!--<button type="reset" class="btn btn-default">Reset</button>-->
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
					</div>
					<!-- end: page -->
				</section>
                </div>

<aside id="sidebar-right" class="sidebar-right">
    <div class="nano">
        <div class="nano-content">
            <a href="#" class="mobile-close visible-xs">
                Collapse <i class="fa fa-chevron-right"></i>
            </a>

            <div class="sidebar-right-wrapper">

                <div class="sidebar-widget widget-calendar">
                    <h6>Upcoming Tasks</h6>
                    <div data-plugin-datepicker data-plugin-skin="dark" ></div>

                    <ul>
                        <li>
                            <time datetime="2014-04-19T00:00+00:00">04/19/2014</time>
                            <span>Company Meeting</span>
                        </li>
                    </ul>
                </div>

                <div class="sidebar-widget widget-friends">
                    <h6>Friends</h6>
                    <ul>
                        <li class="status-online">
                            <figure class="profile-picture">
                                <img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Doe" class="img-circle">
                            </figure>
                            <div class="profile-info">
                                <span class="name">Joseph Doe Junior</span>
                                <span class="title">Hey, how are you?</span>
                            </div>
                        </li>
                        <li class="status-online">
                            <figure class="profile-picture">
                                <img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Doe" class="img-circle">
                            </figure>
                            <div class="profile-info">
                                <span class="name">Joseph Doe Junior</span>
                                <span class="title">Hey, how are you?</span>
                            </div>
                        </li>
                        <li class="status-offline">
                            <figure class="profile-picture">
                                <img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Doe" class="img-circle">
                            </figure>
                            <div class="profile-info">
                                <span class="name">Joseph Doe Junior</span>
                                <span class="title">Hey, how are you?</span>
                            </div>
                        </li>
                        <li class="status-offline">
                            <figure class="profile-picture">
                                <img src="{{asset('backend/assets/images/!sample-user.jpg')}}" alt="Joseph Doe" class="img-circle">
                            </figure>
                            <div class="profile-info">
                                <span class="name">Joseph Doe Junior</span>
                                <span class="title">Hey, how are you?</span>
                            </div>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</aside>
</section>

<!-- Vendor -->
<script src="{{asset('backend/assets/vendor/jquery/jquery.js')}}"></script>
<script src="{{asset('backend/assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')}}"></script>
<script src="{{asset('backend/assets/vendor/bootstrap/js/bootstrap.js')}}"></script>
<script src="{{asset('backend/assets/vendor/nanoscroller/nanoscroller.js')}}"></script>
<script src="{{asset('backend/assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')}}"></script>
<script src="{{asset('backend/assets/vendor/magnific-popup/magnific-popup.js')}}"></script>
<script src="{{asset('backend/assets/vendor/jquery-placeholder/jquery.placeholder.js')}}"></script>

<!-- Specific Page Vendor -->
<script src="{{asset('backend/assets/vendor/select2/select2.js')}}"></script>
<script src="{{asset('backend/assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')}}"></script>
<script src="{{asset('backend/assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')}}"></script>
<script src="{{asset('backend/assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')}}"></script>

<!-- Theme Base, Components and Settings -->
<script src="{{asset('backend/assets/javascripts/theme.js')}}"></script>

<!-- Theme Custom -->
<script src="{{asset('backend/assets/javascripts/theme.custom.js')}}"></script>

<!-- Theme Initialization Files -->
<script src="{{asset('backend/assets/javascripts/theme.init.js')}}"></script>


<!-- Examples -->
<script src="{{asset('backend/assets/javascripts/tables/examples.datatables.default.js')}}"></script>
<script src="{{asset('backend/assets/javascripts/tables/examples.datatables.row.with.details.js')}}"></script>
<script src="{{asset('backend/assets/javascripts/tables/examples.datatables.tabletools.js')}}"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function()
{
	$("#jilla_name").on("change",function()
	{
		var id=$(this).val();
		$.ajax({
			url:'/api/jillaid/'+id,
			method:'get',
			success:function(data)
			{
				//var test=data.split("::");
				$("#taluka_name").html(data);
			},	
			error:function(data)
			{
				$("#taluka_name").html("");
			}
		});
	});
	$("#taluka_name").on("change",function()
	{
		var id=$(this).val();
		//alert(id);
		$.ajax({
			url:'/api/jillaid/'+id,
			method:'get',
			success:function(data)
			{
				//var test=data.split("::");
				$("#gramonchange").html(data);
			},	
			error:function(data)
			{
				$("#gramonchange").html("");
			}
		});
	});
    $("#gramonchange").on("change",function()
    {
        var id=$(this).val();
		//alert(id);
		var data={
			jilla_id:$("#jilla_name").val(),
			taluka_id:$("#taluka_name").val(),
			gram_id:$(this).val()
		}
		$.ajax({
			url:'/api/gramdetails/',
			method:'get',
			data:data,
			success:function(data)
			{
				var test=data.split("::");
				$("#nivas").val(test[0]);
				$("#commers").val(test[1]);
				$("#indrstrial").val(test[2]);
				$j=3;
				for($i=1; $i<=6; $i++)
				{
				
					$("#chf"+$i+"").val(test[$j]);
					$j++;
				}
				$("#a1").val(test[9]);
				$("#b1").val(test[10]);
				$("#c1").val(test[11]);
				$("#d1").val(test[12]);
				$("#e1").val(test[13]);
				$("#f1").val(test[14]);
				$("#g1").val(test[15]);
				$("#h1").val(test[16]);
				$("#i1").val(test[17]);

				$("#a2").val(test[18]);
				$("#b2").val(test[19]);
				$("#c2").val(test[20]);
				$("#d2").val(test[21]);
				$("#e2").val(test[22]);
				$("#f2").val(test[23]);
				$("#g2").val(test[24]);
				$("#h2").val(test[25]);
				$("#i2").val(test[26]);

				$("#a3").val(test[27]);
				$("#b3").val(test[28]);
				$("#c3").val(test[29]);
				$("#d3").val(test[30]);
				$("#e3").val(test[31]);
				$("#f3").val(test[32]);
				$("#g3").val(test[33]);
				$("#h3").val(test[34]);
				$("#i3").val(test[35]);

				$("#a4").val(test[36]);
				$("#b4").val(test[37]);
				$("#c4").val(test[38]);
				$("#d4").val(test[39]);
				$("#e4").val(test[40]);
				$("#f4").val(test[41]);
				$("#g4").val(test[42]);
				$("#h4").val(test[43]);
				$("#i4").val(test[44]);

				$("#a5").val(test[45]);
				$("#b5").val(test[46]);
				$("#c5").val(test[47]);
				$("#d5").val(test[48]);
				$("#e5").val(test[49]);
				$("#f5").val(test[50]);
				$("#g5").val(test[51]);
				$("#h5").val(test[52]);
				$("#i5").val(test[53]);

				//alert(test[52]);

				$("#karach_dar").val(test[54]);
				$("#diva_kar").val(test[55]);
				$("#aarogya_kar").val(test[56]);
				$("#panipatt_kar").val(test[57]);
				$("#panipatt_sep_kar").val(test[58]);

			},
			error:function(data)
			{
				alert(data);
			}
		});
    }); 
});
</script>
</body>
</html>