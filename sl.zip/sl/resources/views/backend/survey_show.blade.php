@extends('backend.header')
@section('index-content')

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>सर्वेक्षण तपशील</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="/">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>टेबल</span></li>
								<li><span>सर्वेक्षण</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a>
								</div>
						
								<h2 class="panel-title">सर्वेक्षण तपशील</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none">
									<thead>
									@foreach($survey_i as $sur)
										<tr>
											<th>सर्वेक्षण क्र. </th><td>{{$sur->id}}</td></tr>
											<tr><th>तालुका</th><td>{{$sur->area_name}}</td></tr>
											<tr><th>ग्रामपंचायत</th><td class="center hidden-phone">{{$sur->name}}</td></tr>
											
											<tr><th>स्वयंघोषणापत्र  करुन देणार</th><td class="center hidden-phone">{{$sur->name}}</td></tr>
											<tr><th class="hidden-phone">स्वयंघोषणापत्र  करुन घेणार</th><td class="center hidden-phone">{{$sur->gram_name}}</td></tr>
											<tr><th class="hidden-phone">भोगवटदाराचे नांव</th><td class="center hidden-phone">{{$sur->name2}}</td></tr>
											<tr><th class="hidden-phone">सिटीसव्‍ह मिळकत धारकाचे नांव</th><td class="center hidden-phone">{{$sur->survey_name}}</td></tr>
											<tr><th class="hidden-phone">मोबाइल नं</th><td class="center hidden-phone">{{$sur->mbl}}</td></tr>
											<tr><th class="hidden-phone">आधार नं</th><td class="center hidden-phone">{{$sur->adhar}}</td></tr>
											<tr><th class="hidden-phone">पत्नीचे आधार नं</th><td class="center hidden-phone">{{$sur->wife_adhar}}</td></tr>
											<tr><th class="hidden-phone">पत्नीचे मोबाइल नं</th><td class="center hidden-phone">{{$sur->wife_mbl}}</td></tr>
											
											<tr><th class="hidden-phone">जुना मिळकत क्र</th><td class="center hidden-phone">{{$sur->old_tax_no}}</td></tr>
											<tr><th class="hidden-phone">सि.सि नं.</th><td class="center hidden-phone">{{$sur->s_s_no}}</td></tr>
											<tr><th class="hidden-phone">सि. सि. चैा मि.</th><td class="center hidden-phone">{{$sur->s_s_m}}</td></tr>
											<tr><th class="hidden-phone">गट नं.</th><td class="center hidden-phone">{{$sur->group_no}}</td></tr>
											<tr><th class="hidden-phone">प्लॉट नं.</th><td class="center hidden-phone">{{$sur->plot_no}}</td></tr>
											<tr><th class="hidden-phone">बांधकाम वर्ष</th><td class="center hidden-phone">{{$sur->yr_const}}</td></tr>
											<tr><th class="hidden-phone">उत्तर / दक्षिण</th><td class="center hidden-phone">{{$sur->north_south}}</td></tr>
											<tr><th class="hidden-phone">पुर्व / पश्चिम</th><td class="center hidden-phone">{{$sur->east_west}}</td></tr>
											
											<tr><th class="hidden-phone">उत्तर</th><td class="center hidden-phone">{{$sur->north}}</td></tr>
											<tr><th class="hidden-phone">दक्षिण</th><td class="center hidden-phone">{{$sur->south}}</td></tr>
											<tr><th class="hidden-phone">पुर्व</th><td class="center hidden-phone">{{$sur->east}}</td></tr>
											<tr><th class="hidden-phone">पश्चिम</th><td class="center hidden-phone">{{$sur->west}}</td></tr>
											<tr><th class="hidden-phone">व्दार</th><td class="center hidden-phone">{{$sur->gate}}</td></tr>
											<tr><th class="hidden-phone">Image</th><td class="center hidden-phone"><img src="{{asset('/image')}}/{{$sur->img}}" height="150px" width="150px"></td></tr>
											<tr><th class="hidden-phone">Map Image</th><td class="center hidden-phone"><img src="{{asset('/image')}}/{{$sur->mapimg}}" height="150px" width="150px"></td></tr>
											<tr><th class="hidden-phone">Status</th><td class="center hidden-phone">{{$sur->status}}</td></tr>
											
											
										</tr>
										@endforeach
									</thead>
								</table>
								<table>
								<tr>
											<th>मिळकतीचे वर्णन</th>
											<th>चाै.फुट</th>
											<th>चाै.मि.</th>
											<th>एकुण कर</th>
								</tr>
								
								
								@foreach($k as $l)
								<tr>
								<td>{{$l->varnana_name}}</td>
								<td>{{$l->ch_fu}}</td>
								<td>{{$l->ch_me}}</td>
								<td>{{$l->total}}</td>
								</tr>
								@endforeach
								
								
								
								</table>
							</div>
						</section>
						</section>
						
						
			@stop