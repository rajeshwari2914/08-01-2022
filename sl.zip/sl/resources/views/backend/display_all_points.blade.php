<?php
foreach($bharanks as $bh)
{
    $d=$bh->amt;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr1=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr1,$value);
            
        }
    }
}
foreach($readyreknals as $bh)
{
    $d=$bh->rate;
    $json_array=json_decode( preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $d),true);
    $arr2=array();
    foreach($json_array as $key=>$arrays){
        foreach($arrays as $value){
            
                array_push($arr2,$value);
            
        }
    }
    
}

$arr3=array();
foreach($ghasaras as $k)
{
    
    $data=array(
        "one"=>$k->one,
        "two"=>$k->two,
        "three"=>$k->three,
        "four"=>$k->four,
        "five"=>$k->five,
        "six"=>$k->six,
        "seven"=>$k->seven,
        "eight"=>$k->eight,
        "greater_than_sixty"=>$k->greater_than_sixty
    );
    array_push($arr3,$data);
}


echo $arr1[1]."::".$arr1[3]."::".$arr1[5]."::".$arr2[1]."::".$arr2[3]."::".$arr2[5]."::".$arr2[7]."::".$arr2[9]."::".$arr2[11]."::".$arr3[0]["one"]."::".$arr3[0]["two"]."::".$arr3[0]["three"]."::".$arr3[0]["four"]."::".$arr3[0]["five"]."::".$arr3[0]["six"]."::".$arr3[0]["seven"]."::".$arr3[0]["eight"]."::".$arr3[0]["greater_than_sixty"]."::".$arr3[1]["one"]."::".$arr3[1]["two"]."::".$arr3[1]["three"]."::".$arr3[1]["four"]."::".$arr3[1]["five"]."::".$arr3[1]["six"]."::".$arr3[1]["seven"]."::".$arr3[1]["eight"]."::".$arr3[1]["greater_than_sixty"]."::".$arr3[2]["one"]."::".$arr3[2]["two"]."::".$arr3[2]["three"]."::".$arr3[2]["four"]."::".$arr3[2]["five"]."::".$arr3[2]["six"]."::".$arr3[2]["seven"]."::".$arr3[2]["eight"]."::".$arr3[2]["greater_than_sixty"]."::".$arr3[3]["one"]."::".$arr3[3]["two"]."::".$arr3[3]["three"]."::".$arr3[3]["four"]."::".$arr3[3]["five"]."::".$arr3[3]["six"]."::".$arr3[3]["seven"]."::".$arr3[3]["eight"]."::".$arr3[3]["greater_than_sixty"]."::".$arr3[4]["one"]."::".$arr3[4]["two"]."::".$arr3[4]["three"]."::".$arr3[4]["four"]."::".$arr3[4]["five"]."::".$arr3[4]["six"]."::".$arr3[4]["seven"]."::".$arr3[4]["eight"]."::".$arr3[4]["greater_than_sixty"]."::".$additional[0]->karach_dar."::".$additional[0]->divabatti_kar."::".$additional[0]->aarogya_kar."::".$additional[0]->panipatti_kar."::".$additional[0]->panipatti_special_kar;
?>