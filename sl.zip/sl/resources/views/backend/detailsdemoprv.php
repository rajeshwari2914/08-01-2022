<html>
    <head>
    <title>Print Detail</title>
    <style>
    th
    {
        font-size: 12px;
    }
    td
    {
        font-size: 12px;
    }
    </style>    
</head>
    
    <body>
@foreach($arr as $p)
<center><span>जिल्हा:- {{$jillaname[0]->area_name}}</span><span style="margin-left:10px;">तालुका:- {{$talukaname[0]->area_name}}</span><span style="margin-left:10px;">ग्रामपंचायत:- {{$gramname[0]->area_name}}</span></center>
<table border=1>
    <tr>
        <th>अ. क्र. १ </th>
        <th>मालमता क्रमांक २</th>
        <th>मालमतेचे वर्णन ३</th>
        <th>मालकाचे नाव ४</th>
        <th>भोगवटादाराचे नाव ५</th>
        <th>मिळकत बांधकामाचे वर्ष ६</th>
        <th>क्षेत्रफळ(चौरस फुट ७)</th>
        <th>क्षेत्रफळ(चौरस मीटर ८)</th>
        <th>रेडीरेकनर दर प्रति चो.मि.(रुपये) जमीन ९</th>
        <th>रेडीरेकनर दर प्रति चो.मि.(रुपये) बांधकाम १०</th>
        <th>घसारा दर ११</th>
        <th>भारांक १२</th>
        <th>भांडवली मूल्य (रुपये) १३</th>
        <th>कराचा दर (पैसे) १४</th>
        <th>घरपट्टी कर १५</th>
        <th>दिवाबत्ती कर १६</th>
        <th>आरोग्य कर १७</th>
        <th>पाणीपट्टी कर १८</th>
        <th>स्पेशल पाणीपट्टी कर १९</th>
        <th>एकूण २०</th>
        <th>अपिलाचे निकाल आणि त्यानंतर केलेले बदल २१</th>
        <th>२२</th>
    </tr>
    <tr>
        <td>10</td>
        <td>9</td>
        <td>उ.द. पु.प</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>

    </tr>
    <?php
    $i=1;
    ?>
    @foreach($k as $v)
    
    <tr>
        <td></td>
        <td></td>
        <td>{{$v->varnana_name}}</td>
        <?php
        if($v->ch_fu!=null && $v->ch_me!=null)
        {
        ?>
        <td>{{$p->name}}</td>
        <?php
        }
        ?>
        <?php
        if($v->ch_fu!=null && $v->ch_me!=null)
        {
        ?>
        <td>{{$p->name2}}</td>
        <?php
        }
        ?>
        <?php
        if($v->ch_fu!=null && $v->ch_me!=null)
        {
        ?>
        <td>{{$p->yr_const}}</td>
        <?php
        }
        ?>
        <td>{{$v->ch_fu}}</td>
        <td>{{$v->ch_me}}</td>
        @foreach($r as $o)
        <?php
        $var=$v->varnana_name;
        $ty=$o->types;
        if($v->ch_fu!=null && $v->ch_me!=null)
        {
            //echo $p->yr_const;
            if($ty==$var && $p->yr_const!=null)
            {
        ?>
        <td>{{$o->rates}}</td>
        <?php
            }    
        }
        ?>
        @endforeach
        <td></td>
        
        @foreach($gha as $gg)
        <?php
        if($v->ch_fu!=null && $v->ch_me!=null)
        {
          
        if($v->varnana_name==$gg->types && $p->yr_const!=null)
        {
        ?>
        <td>{{$gg->one}}</td> 
        <?php
        }
    }
        ?>
        @endforeach
       
        <td></td>
        <td></td>

        <td></td>

        <td></td>
        <!-- <td>{{$additional[0]->karach_dar}}</td>  -->
        <td></td>
        
        @foreach($b as $okk)
        <?php
        
        if($v->varnana_name==$okk->type)
        {
        ?>
        <td>{{$okk->amt}}</td>
        <?php
        }
        
        ?>
        @endforeach
        
        <td></td>

        <!-- <td>{{$additional[0]->karach_dar}}</td> -->
        
         <!-- <td>{{$additional[0]->divabatti_kar}}</td>
        <td>{{$additional[0]->aarogya_kar}}</td>
        <td>{{$additional[0]->panipatti_kar}}</td>
        <td>{{$additional[0]->panipatti_special_kar}}</td>  -->
        
        <td></td>
        <td></td>
       
        
    </tr>
    <?php $i++;?>
    @endforeach
    
    <tr>
        <td></td>
        <td></td>
        <td>उत्तर.</td>
        <td>{{$p->north}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>दक्षिण.</td>
        <td>{{$p->south}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>पुर्व</td>
        <td>{{$p->east}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>पच्शिम.</td>
        <td>{{$p->west}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>व्दार</td>
        <td>{{$p->gate}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>शौचालय (आहे/नाही)</td>
        <td>{{$p->washroom}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>नळ (आहे/नाही)</td>
        <td>{{$p->nal}}</td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
    </tr>
</table>
</body>
</html>
@endforeach